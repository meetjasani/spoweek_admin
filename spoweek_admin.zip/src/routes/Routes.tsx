import * as React from 'react'
import { Switch } from 'react-router'
import Pages from '../pages'

function Routes() {
    return (
        <div>
            <Switch>
                <Pages />
            </Switch>
        </div>
    )
}

export default Routes
