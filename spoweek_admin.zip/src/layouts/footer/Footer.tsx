import React from 'react'
import "./footer.css";

function Footer() {
    return (
        <div>
            <footer className="footer-h-w fixed-bottom">
                <p>Copyright © SPOWEEK. ALL RIGHTS RESERVED.</p>
            </footer>
        </div>
    )
}

export default Footer
